# adding
```bash
sudo add-apt-repository ppa:alexander314/dev-tooly
```
