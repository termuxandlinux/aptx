# adding
```bash
sudo add-apt-repository ppa:alexander314/dev-tooly
```
Otherwise over wget:
```bash
wget https://github.com/termuxandlinux/aptx/raw/main/.backup/1.1/aptx_1.1_armhf.deb
```
If you use Termux
```bash
wget https://github.com/termuxandlinux/aptx/raw/main/.backup/termux/aptx_1.1_all.deb
```


